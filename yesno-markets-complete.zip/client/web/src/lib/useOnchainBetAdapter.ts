import { usePlaceBet } from "@/hooks/useYesNo";

export function useOnchainBetAdapter(marketPk?: string) {
  const place = usePlaceBet(marketPk);
  return {
    onConfirm: async (side: "yes" | "no", lamports: number) => {
      const idx = side === "yes" ? 0 : 1;
      return place(idx, lamports);
    },
  };
}
