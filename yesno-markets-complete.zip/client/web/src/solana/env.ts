// src/solana/env.ts
const HELIUS_RPC_URL = "https://devnet.helius-rpc.com/?api-key=837c2c48-6328-44b6-a49f-3a25e0567a96";

export const RPC_URL =
  (import.meta as any).env?.VITE_RPC_URL || HELIUS_RPC_URL;

if (typeof window !== "undefined") {
  console.log("[yesno] Using Solana RPC endpoint:", RPC_URL);
}
export const PROGRAM_ID =
  (import.meta as any).env?.VITE_PROGRAM_ID || (undefined as unknown as string);
export const COMMITMENT =
  ((import.meta as any).env?.VITE_COMMITMENT as "processed"|"confirmed"|"finalized") || "confirmed";
export const PRIORITY_MICROLAMPORTS = Number((import.meta as any).env?.VITE_PRIORITY_MICROLAMPORTS || 0);
