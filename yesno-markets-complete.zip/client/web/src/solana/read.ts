// src/solana/read.ts
import type { Program } from "@coral-xyz/anchor";
import { web3 } from "@coral-xyz/anchor";
import { PublicKey } from "@solana/web3.js";
import type { YesnoMarkets } from "../idl/yesno_markets";
import { getConfigPda } from "./idlHelpers";

export async function fetchAllMarkets(program: Program<YesnoMarkets> | null) {
  if (!program) {
    console.warn("[yesno] fetchAllMarkets: program not ready");
    return [];
  }

  try {
    const markets = await program.account.market.all();
    console.log("[yesno] fetched markets", { count: markets.length });
    return markets;
  } catch (err) {
    console.error("[yesno] fetchAllMarkets failed", err);
    return [];
  }
}

export async function fetchMarket(program: Program<YesnoMarkets> | null, pubkey: string | PublicKey) {
  if (!program) {
    console.warn("[yesno] fetchMarket: program not ready");
    return null;
  }

  try {
    const marketPk = new web3.PublicKey(pubkey);
    const market = await program.account.market.fetch(marketPk);
    return market;
  } catch (err) {
    console.error("[yesno] fetchMarket failed", err);
    return null;
  }
}

export async function fetchUserPositions(program: Program<YesnoMarkets> | null, owner: string | PublicKey) {
  if (!program) {
    console.warn("[yesno] fetchUserPositions: program not ready");
    return [];
  }

  try {
  const ownerPk = new web3.PublicKey(owner);
    const allPositions = await program.account.position.all();
    
    // Filter by owner in JavaScript
    const userPositions = allPositions.filter((p: any) => {
      const posOwner = p.account.owner || p.account.user;
      if (!posOwner) return false;
      const ownerPubkey = posOwner.toBase58 ? posOwner.toBase58() : posOwner.toString();
      return ownerPubkey === ownerPk.toBase58();
    });
    
    return userPositions;
  } catch (err) {
    console.error("[yesno] fetchUserPositions failed", err);
    return [];
  }
}

export async function fetchConfig(program: Program<YesnoMarkets> | null) {
  if (!program) {
    console.warn("[yesno] fetchConfig: program not ready");
    return null;
  }

  try {
    // Use program.programId directly to ensure consistency with Anchor's internal derivation
    const programId = program.programId;
    const [configPda] = getConfigPda(programId);
    const config = await program.account.config.fetch(configPda);
    return config;
  } catch (err) {
    console.error("[yesno] fetchConfig failed", err);
    return null;
  }
}
