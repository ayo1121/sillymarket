// src/solana/connection.ts
import { Connection } from "@solana/web3.js";

const HELIUS_RPC_URL = "https://devnet.helius-rpc.com/?api-key=837c2c48-6328-44b6-a49f-3a25e0567a96";
const url = import.meta.env.VITE_RPC_URL?.toString() || HELIUS_RPC_URL;

export const commitment: "processed" | "confirmed" | "finalized" =
  (import.meta.env.VITE_COMMITMENT as any) || "confirmed";

export const connection = new Connection(url, { commitment });

if (typeof window !== "undefined") {
  console.log("[yesno] Connection using Solana RPC endpoint:", url);
}
