// src/solana/actions.ts
import type { Program, Idl, Address } from "@coral-xyz/anchor";
import { Program as AnchorProgram } from "@coral-xyz/anchor";
import * as anchor from "@coral-xyz/anchor";
import { web3 } from "@coral-xyz/anchor";
import BN from "bn.js";
import { computeBudgetIxs } from "./tx";
import { findMarketPda, findPositionPda } from "./pdas";
import { getConfigPda } from "./idlHelpers";
import { PublicKey, SystemProgram } from "@solana/web3.js";
import type { YesnoMarkets } from "../idl/yesno_markets";
import type { WalletContextState } from "@solana/wallet-adapter-react";
import { getAnchorProgramWithProvider } from "./program";
/**
 * Hash question and answers - matches Rust hash_question_and_answers
 * Uses Web Crypto API for browser compatibility
 */
export async function hashQuestionAndAnswers(question: string, answers: string[]): Promise<Uint8Array> {
  const buf: Uint8Array[] = [];
  
  // "yesno_markets_v1"
  buf.push(new TextEncoder().encode("yesno_markets_v1"));
  
  // question length (u32 le)
  const qLen = new Uint8Array(4);
  new DataView(qLen.buffer).setUint32(0, question.length, true);
  buf.push(qLen);
  
  // question bytes
  buf.push(new TextEncoder().encode(question));
  
  // answers length (u32 le)
  const aLen = new Uint8Array(4);
  new DataView(aLen.buffer).setUint32(0, answers.length, true);
  buf.push(aLen);
  
  // each answer: length (u32 le) + bytes
  for (const a of answers) {
    const len = new Uint8Array(4);
    new DataView(len.buffer).setUint32(0, a.length, true);
    buf.push(len);
    buf.push(new TextEncoder().encode(a));
  }
  
  // Concatenate all
  const totalLen = buf.reduce((sum, b) => sum + b.length, 0);
  const combined = new Uint8Array(totalLen);
  let offset = 0;
  for (const b of buf) {
    combined.set(b, offset);
    offset += b.length;
  }
  
  // SHA256 hash
  const hashBuffer = await crypto.subtle.digest("SHA-256", combined);
  return new Uint8Array(hashBuffer);
}

export async function callIx(
  program: Program<Idl>,
  ixName: string,
  args: any[],
  accounts: Record<string, Address>
) {
  const keys = Object.keys(program.methods);
  const norm = (s: string) => s.toLowerCase().replace(/_/g, "");
  const found = keys.find((k) => norm(k) === norm(ixName)) || keys.find((k) => k.toLowerCase() === ixName.toLowerCase());
  const m = found ? (program.methods as any)[found] : (program.methods as any)[ixName];
  if (!m) {
    throw new Error(`Method ${ixName} not found (have: ${keys.join(", ")})`);
  }
  
  // Debug logging before rpc() call
  if (ixName === "create_market" || ixName.toLowerCase().includes("createmarket")) {
    console.log("[CreateMarket] available instructions in IDL:",
      (program.idl as any)?.instructions?.map((ix: any) => ix.name)
    );
    console.log("[CreateMarket] has methods.createMarket:",
      typeof (program as any).methods?.createMarket || typeof (program as any).methods?.create_market
    );
  }
  
  return await m(...args).accounts(accounts).preInstructions(computeBudgetIxs()).rpc({ commitment: "confirmed" });
}

/**
 * Create a market - matches Rust create_market
 */
// @ts-ignore - YesnoMarkets type compatibility issue with Anchor Idl
export async function createMarket(
  program: AnchorProgram<YesnoMarkets> | any,
  wallet: WalletContextState,
  args: {
    cutoffTs: number; // Unix timestamp
    question: string;
    answers: string[];
    imageUrl: string;
  }
) {
  if (!wallet.publicKey) throw new Error("Wallet not connected");

  // Normalize inputs (trim, validate)
  const question = args.question.trim();
  const answers = args.answers.map(a => a.trim());
  const imageUrl = args.imageUrl.trim();

  // Validate
  if (question.length === 0 || question.length > 1024) {
    throw new Error("Question must be 1-1024 characters");
  }
  if (answers.length < 2 || answers.length > 5) {
    throw new Error("Must have 2-5 answers");
  }
  for (const a of answers) {
    if (a.length === 0 || a.length > 64) {
      throw new Error("Each answer must be 1-64 characters");
    }
  }
  if (imageUrl.length > 200) {
    throw new Error("Image URL must be <= 200 characters");
  }

  // Calculate hash
  const questionHash = await hashQuestionAndAnswers(question, answers);

  // Find market PDA
  const programId = program.programId;
  const [marketPda] = findMarketPda(programId, wallet.publicKey, args.cutoffTs, questionHash);

  // Get config PDA and fetch config to get the fee wallet
  const [configPda] = getConfigPda(programId);
  const config = await (program.account as any).config.fetch(configPda);
  const feeWalletStr =
    (config as any).feeWallet?.toString?.() ||
    (config as any).fee_wallet?.toString?.();

  if (!feeWalletStr) {
    throw new Error("Config has no fee wallet set");
  }

  const platformFeeWallet = new PublicKey(feeWalletStr);

  console.log("[CreateMarket] using platformFeeWallet:", platformFeeWallet.toBase58());

  // Wrap i64/u64 args in BN (from IDL: cutoff_ts is i64)
  const cutoffTsBn = new anchor.BN(Number(args.cutoffTs));

  const txSig = await program.methods
    .createMarket(
      cutoffTsBn,
      Array.from(questionHash),
      question,
      answers,
      imageUrl
    )
    .accounts({
      config: configPda,
      creator: wallet.publicKey,
      platformFeeWallet,
      market: marketPda,
      systemProgram: SystemProgram.programId,
    })
    .rpc();

  console.log("[CreateMarket] tx:", txSig);
  return txSig;
}

/**
 * Place a bet - matches Rust place_bet
 */
export async function placeBet(
  program: Program<Idl>,
  params: {
    market: Address;
    user: Address;
    outcomeIndex: number;
    amountLamports: number;
  }
) {
  const marketPk = new PublicKey(params.market);
  const userPk = new PublicKey(params.user);
  // Use program.programId directly to ensure consistency
  const programId = program.programId;

  // Find position PDA
  const [positionPda] = findPositionPda(programId, marketPk, userPk);

  const accounts: Record<string, Address> = {
    market: marketPk,
    user: userPk,
    position: positionPda,
    systemProgram: SystemProgram.programId,
  };

  return callIx(
    program,
    "place_bet",
    [params.outcomeIndex, new BN(params.amountLamports)],
    accounts
  );
}

/**
 * Resolve a market - matches Rust resolve
 */
export async function resolveMarket(
  program: Program<Idl>,
  params: {
    market: Address;
    signer: Address;
    winnerIndex: number; // -2 for VOID, -1 for UNSET, 0+ for winner
    platformFeeWallet: Address;
    creatorWallet: Address;
  }
) {
  // Use program.programId directly to ensure consistency with Anchor's internal derivation
  const programId = program.programId;
  const [configPda] = getConfigPda(programId);

  const accounts: Record<string, Address> = {
    config: configPda,
    market: params.market,
    signer: params.signer,
    platformFeeWallet: params.platformFeeWallet,
    creatorWallet: params.creatorWallet,
    systemProgram: SystemProgram.programId,
  };

  return callIx(program, "resolve", [params.winnerIndex], accounts);
}

/**
 * Claim winnings - matches Rust claim_winnings
 */
export async function claimWinnings(
  program: Program<Idl>,
  params: {
    market: Address;
    user: Address;
  }
) {
  const marketPk = new PublicKey(params.market);
  const userPk = new PublicKey(params.user);
  // Use program.programId directly to ensure consistency
  const programId = program.programId;

  // Find position PDA
  const [positionPda] = findPositionPda(programId, marketPk, userPk);

  const accounts: Record<string, Address> = {
    market: marketPk,
    user: userPk,
    position: positionPda,
    systemProgram: SystemProgram.programId,
  };

  return callIx(program, "claim_winnings", [], accounts);
}

/**
 * Void expired market - matches Rust void_expired
 */
export async function voidExpired(
  program: Program<Idl>,
  params: {
    market: Address;
  }
) {
  const accounts: Record<string, Address> = {
    market: params.market,
    systemProgram: SystemProgram.programId,
  };

  return callIx(program, "void_expired", [], accounts);
}

/**
 * Initialize config - matches Rust initialize
 */
export async function initialize(
  program: Program<Idl>,
  params: {
    authority: PublicKey;
    feeWallet: PublicKey;
    minBetLamports: number;
    maxBetLamports: number;
    adminPreCutoff: boolean;
  }
) {
  // Use program.programId directly to ensure consistency with Anchor's internal derivation
  const programId = program.programId;
  const [configPda] = getConfigPda(programId);

  // Accounts must use camelCase (Anchor converts IDL snake_case to camelCase)
  const accounts: Record<string, Address> = {
    config: configPda,
    authority: params.authority,
    feeWalletAcc: params.feeWallet,
    systemProgram: SystemProgram.programId,
  };

  return callIx(
    program,
    "initialize",
    [
      params.feeWallet,
      new BN(params.minBetLamports),
      new BN(params.maxBetLamports),
      params.adminPreCutoff,
    ],
    accounts
  );
}

/**
 * Initialize config with sensible defaults
 * Uses the wallet as fee wallet and standard min/max bet limits
 */
export async function initializeConfig(
  program: Program<Idl> | null,
  walletPublicKey: PublicKey | null
): Promise<string> {
  if (!program) {
    throw new Error("Program not ready");
  }

  if (!walletPublicKey) {
    throw new Error("Wallet not connected");
  }

  // Use program.programId directly to ensure consistency with Anchor's internal derivation
  // This is critical: Anchor derives PDAs using program.programId internally
  const programId = program.programId;
  const [configPda, bump] = getConfigPda(programId);

  console.log("[initializeConfig] Config PDA:", {
    address: configPda.toBase58(),
    bump,
    programId: programId.toBase58(),
  });

  // Use sensible defaults matching Rust constants:
  // MIN_BET_LAMPORTS = 10_000_000 (0.01 SOL)
  // MAX_BET_LAMPORTS = 100_000 * 1_000_000_000 (100k SOL)
  const minBetLamports = 10_000_000; // 0.01 SOL
  const maxBetLamports = 100_000 * 1_000_000_000; // 100k SOL
  const adminPreCutoff = false; // Default to false

  // Use wallet as fee wallet
  const feeWallet = walletPublicKey;

  // Accounts must use camelCase (Anchor converts IDL snake_case to camelCase)
  // IDL has: config, authority, fee_wallet_acc, system_program
  // Anchor expects: config, authority, feeWalletAcc, systemProgram
  const accounts: Record<string, Address> = {
    config: configPda,
    authority: walletPublicKey,
    feeWalletAcc: feeWallet,
    systemProgram: SystemProgram.programId,
  };

  console.log("[initializeConfig] Accounts for initialize:", {
    config: typeof accounts.config === 'string' ? accounts.config : accounts.config.toBase58(),
    authority: typeof accounts.authority === 'string' ? accounts.authority : accounts.authority.toBase58(),
    feeWalletAcc: typeof accounts.feeWalletAcc === 'string' ? accounts.feeWalletAcc : accounts.feeWalletAcc.toBase58(),
    systemProgram: typeof accounts.systemProgram === 'string' ? accounts.systemProgram : accounts.systemProgram.toBase58(),
  });

  console.log("[initializeConfig] Calling initialize with args:", {
    feeWallet: feeWallet.toBase58(),
    minBetLamports,
    maxBetLamports,
    adminPreCutoff,
  });

  try {
    const sig = await callIx(
      program,
      "initialize",
      [
        feeWallet,
        new BN(minBetLamports),
        new BN(maxBetLamports),
        adminPreCutoff,
      ],
      accounts
    );

    console.log("[initializeConfig] ✅ Config initialized successfully:", sig);
    return sig;
  } catch (err: any) {
    console.error("[initializeConfig] ❌ Failed to initialize config:", err);
    
    // Enhanced error logging for debugging
    if (err?.logs) {
      console.error("[initializeConfig] Transaction logs:", err.logs);
    }
    if (err?.transactionLogs) {
      console.error("[initializeConfig] Transaction logs (alt):", err.transactionLogs);
    }
    if (err?.transactionMessage) {
      console.error("[initializeConfig] Transaction message:", err.transactionMessage);
    }
    if (err?.simulationResponse) {
      console.error("[initializeConfig] Simulation response:", err.simulationResponse);
    }
    if (err?.error) {
      console.error("[initializeConfig] Error details:", err.error);
    }
    
    throw err;
  }
}

/**
 * Set authority - matches Rust set_authority
 */
export async function setAuthority(
  program: Program<Idl>,
  params: {
    authority: PublicKey;
    newAuthority: PublicKey;
  }
) {
  // Use program.programId directly to ensure consistency with Anchor's internal derivation
  const programId = program.programId;
  const [configPda] = getConfigPda(programId);

  const accounts: Record<string, Address> = {
    authority: params.authority,
    config: configPda,
  };

  return callIx(program, "set_authority", [params.newAuthority], accounts);
}

/**
 * Set fee wallet - matches Rust set_fee_wallet
 * Uses standard Anchor .methods().accounts().rpc() pattern
 */
export async function setFeeWallet(params: {
  newFeeWalletStr: string;
  wallet: WalletContextState;
}): Promise<string> {
  const { newFeeWalletStr, wallet } = params;

  console.log("[setFeeWallet] Entered", { newFeeWalletStr });

  if (!wallet.publicKey) {
    throw new Error("[setFeeWallet] Wallet not connected");
  }

  const { program, provider } = getAnchorProgramWithProvider(wallet) || {};
  if (!program || !provider) {
    throw new Error("[setFeeWallet] Program not initialized");
  }

  const authority = wallet.publicKey;
  const newFeeWallet = new PublicKey(newFeeWalletStr);

  // Get config PDA the same way other admin actions do
  const [configPda] = getConfigPda(program.programId);

  // Use the IDL-driven methods builder so accounts order and signer metadata
  // come directly from the canonical IDL generated by Anchor.
  const builder =
    program.methods.setFeeWallet?.(newFeeWallet) ??
    program.methods.set_fee_wallet?.(newFeeWallet);

  if (!builder) {
    throw new Error("[setFeeWallet] methods.setFeeWallet not found on program");
  }

  const txSig = await builder
    .accounts({
      config: configPda,
      authority,
      systemProgram: SystemProgram.programId,
    })
    .rpc();

  console.log("[setFeeWallet] ✅ success", { txSig });
  return txSig;
}

/**
 * Close position - matches Rust close_position
 */
export async function closePosition(
  program: Program<Idl>,
  params: {
    user: PublicKey;
    market: PublicKey;
  }
) {
  // Use program.programId directly to ensure consistency
  const programId = program.programId;
  const [positionPda] = findPositionPda(programId, params.market, params.user);

  const accounts: Record<string, Address> = {
    user: params.user,
    position: positionPda,
  };

  return callIx(program, "close_position", [], accounts);
}
