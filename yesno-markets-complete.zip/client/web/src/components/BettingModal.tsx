import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { z } from "zod";
import { toast } from "@/hooks/use-toast";

interface BettingModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  question: string;
  betType: "yes" | "no";
  odds: string;
  onConfirm?: (betType: "yes" | "no", lamports: number) => Promise<any> | void;
}

const toLamports = (s: string) => Math.round(parseFloat(String(s ?? "0").trim()) * 1e9);

export const BettingModal = ({ open, onOpenChange, question, betType, odds, onConfirm }: BettingModalProps) => {
  const [amount, setAmount] = useState("");

  const handleConfirm = async () => {
    // Validate bet input using zod
    const betSchema = z.object({
      amount: z.number()
        .positive("Amount must be positive")
        .max(1000000, "Exceeds maximum bet limit")
        .finite("Amount must be a valid number"),
      bet_type: z.enum(['yes', 'no']),
    });

    const parsedAmount = parseFloat(amount);
    
    const validationResult = betSchema.safeParse({
      amount: parsedAmount,
      bet_type: betType,
    });

    if (!validationResult.success) {
      toast({
        title: "Validation Error",
        description: validationResult.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    try {
      if (typeof onConfirm === "function") {
        await onConfirm(betType, toLamports(validationResult.data.amount.toString()));
      }
    } catch (e) {
      console.error(e);
    }
    onOpenChange(false);
    setAmount("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="win95-window bg-background p-0 max-w-md border-0">
        <div className="bg-primary text-primary-foreground px-3 py-2 flex items-center justify-between">
          <span className="font-black text-sm tracking-tight">place bet</span>
          <button 
            onClick={() => onOpenChange(false)}
            className="w-4 h-4 win95-raised bg-background flex items-center justify-center text-foreground text-xs font-black hover:bg-accent"
          >
            ×
          </button>
        </div>
        
        <div className="win95-sunken bg-background p-6 m-1">
          <div className="space-y-4">
            <div className="win95-sunken bg-input p-3">
              <div className="text-xs text-muted-foreground font-bold mb-1">market</div>
              <div className="text-sm font-black">{question}</div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="win95-sunken bg-input p-3">
                <div className="text-xs text-muted-foreground font-bold mb-1">betting on</div>
                <div className={`text-lg font-black ${betType === "yes" ? "text-brand-yes" : "text-brand-no"}`}>
                  {betType} {betType === "yes" ? ":)" : ":("}
                </div>
              </div>
              <div className="win95-sunken bg-input p-3">
                <div className="text-xs text-muted-foreground font-bold mb-1">payout</div>
                <div className="text-lg font-black">{odds}</div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold">bet amount (sol)</label>
              <Input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="win95-sunken bg-input border-0 h-12 text-lg font-black"
                step="0.01"
                min="0"
              />
            </div>

            <div className="win95-sunken bg-input p-3">
              <div className="flex justify-between text-sm">
                <span className="font-bold">potential return</span>
                <span className="font-black">
                  {amount && !isNaN(parseFloat(amount)) 
                    ? (parseFloat(amount) * parseFloat(odds.replace('x', ''))).toFixed(2)
                    : "0.00"} sol
                </span>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
              >
                cancel
              </Button>
              <Button
                variant="primary"
                onClick={handleConfirm}
                disabled={!amount || parseFloat(amount) <= 0}
                className="flex-1"
              >
                confirm bet
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
