import React from "react";
import { useMarketsCtx } from "@/hooks/marketsContext";
import { deriveView } from "@/lib/marketAdapter";

export default function OnchainList() {
  const { rows, loading, error } = useMarketsCtx();
  if (error) {
    return <div className="p-4 text-red-600 font-mono">{String((window as any).__idlError?.message || error)}</div>;
  }
  if (loading) return <div className="p-4">loading markets…</div>;
  if (!rows?.length) return <div className="p-4 opacity-70">no on-chain markets</div>;
  return (
    <div className="grid gap-4 p-4">
      {rows.map((r: any) => {
        const v = deriveView(r.account);
        const pk = r.publicKey.toBase58();
        return (
          <div key={pk} className="border border-neutral-300 bg-white p-3 rounded-md">
            <div className="text-xs opacity-60">{pk.slice(0, 4)}…{pk.slice(-4)}</div>
            <div className="text-lg font-semibold">{v.title}</div>
            <div className="text-sm">YES {v.yesPercentage}% · NO {v.noPercentage}% · Vol {v.volumeSOL} SOL</div>
          </div>
        );
      })}
    </div>
  );
}
