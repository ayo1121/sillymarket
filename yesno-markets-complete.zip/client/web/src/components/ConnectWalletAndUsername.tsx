import React, { useEffect, useRef, useState } from "react";
import { useWallet } from "@solana/wallet-adapter-react";
import { useWalletModal } from "@solana/wallet-adapter-react-ui";
import { WalletReadyState } from "@solana/wallet-adapter-base";
import { useWalletIdentity } from "@/auth/walletIdentity";
import UsernameModal from "@/components/UsernameModal";
import { api } from "@/lib/http";
import bs58 from "bs58";
import { Button } from "@/components/ui/button";
import lightbulbIcon from "@/assets/lightbulb-icon.png";

function shorten(pk: string) { return pk ? pk.slice(0,4) + "…" + pk.slice(-4) : ""; }
function forgetRemembered() {
  try {
    localStorage.removeItem("yesno_wallet");
    localStorage.removeItem("walletAdapter");
    localStorage.removeItem("walletName");
  } catch {}
}

export default function ConnectWalletAndUsername({ className }: { className?: string }) {
  const { connected, connecting, connect, disconnect, publicKey, wallet, wallets, select, signMessage } = useWallet() as any;
  const { setVisible } = useWalletModal();
  const { username, setUsername } = useWalletIdentity();

  const [askUsername, setAskUsername] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu on outside click
  useEffect(() => {
    const onClick = (e: MouseEvent) => { if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false); };
    if (menuOpen) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [menuOpen]);

  async function signInIfNeeded() {
    if (!publicKey) return;
    try {
      // ping /me; if ok, already signed in
      const me = await api("/me");
      // Accept both { ok: true, user: ... } and older formats if any
      const user = me?.user ?? null;
      // If we have a session but no username, trigger refresh
      if (me?.ok && user && !user.username) {
        // Trigger username fetch in walletIdentity
        window.dispatchEvent(new Event("username-refresh"));
      }
      return me;
    } catch (e) {
      // Network error - treat as guest, don't throw
      console.warn("[yesno] /me request failed in signInIfNeeded, treating as guest", e);
      return { ok: true, user: null };
    }
    // SIWS start/finish
    const pk58 = publicKey.toBase58();
    const start = await api("/auth/siws/start", { method: "POST", body: JSON.stringify({ pubkey: pk58 }) });
    const msg = new TextEncoder().encode(start.message);
    const signFn = signMessage || wallet?.adapter?.signMessage;
    if (typeof signFn !== "function") {
      alert("This wallet does not support message signing. Try another wallet.");
      return;
    }
    const sig = await signFn(msg);
    const signatureBase58 = bs58.encode(sig);
    const result = await api("/auth/siws/finish", {
      method: "POST",
      body: JSON.stringify({ pubkey: pk58, nonce: start.nonce, signatureBase58 })
    });
    
    // After SIWS, trigger username fetch
    window.dispatchEvent(new Event("username-refresh"));
    return result;
  }

  // Track if we've already prompted for username to avoid repeated prompts
  const [hasPrompted, setHasPrompted] = useState(false);

  // Auto-prompt for username after connection if missing
  useEffect(() => {
    if (connected && publicKey && !username && !hasPrompted) {
      // Wait a bit for SIWS to complete and username to be fetched
      const timer = setTimeout(async () => {
        try {
          // First ensure SIWS is complete
          const me = await signInIfNeeded();
          
          // Check if username exists now (might have been fetched by walletIdentity)
          // Wait a bit more for walletIdentity to update
          await new Promise(resolve => setTimeout(resolve, 500));
          
          // Check again - if still no username, prompt
          const checkMe = await api("/me").catch(() => ({ ok: true, user: null }));
          const user = checkMe?.user ?? null;
          const hasUsername = user && user.username;
          
          if (!hasUsername) {
            setAskUsername(true);
            setHasPrompted(true);
          }
        } catch (e) {
          console.error("Error checking username:", e);
          // If error, still prompt (might be first time user)
          setAskUsername(true);
          setHasPrompted(true);
        }
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [connected, publicKey, username, hasPrompted]);

  const onPrimaryClick = async () => {
    if (!connected) {
      console.log("[ConnectWallet] Opening wallet modal...", { 
        connecting, 
        wallets: wallets?.length, 
        availableWallets: available.length,
        setVisible: typeof setVisible,
        hasPhantom: typeof window !== "undefined" && !!(window as any).solana?.isPhantom,
        currentWallet: wallet?.adapter?.name
      });
      
      // If a wallet is already selected and not connecting, try direct connect first
      if (wallet && wallet.adapter && !connecting) {
        console.log("[ConnectWallet] Wallet already selected:", wallet.adapter.name, "- attempting direct connect");
        try {
          await connect();
          console.log("[ConnectWallet] ✅ Direct connect successful!");
          return;
        } catch (e: any) {
          // Check if it's a WalletNotSelectedError - if so, just open modal
          if (e?.name === "WalletNotSelectedError" || e?.message?.includes("WalletNotSelectedError")) {
            console.warn("[ConnectWallet] Wallet not selected, showing modal instead");
            setVisible(true);
            return;
          }
          console.error("[ConnectWallet] Direct connect failed:", e);
          console.error("[ConnectWallet] Error details:", {
            message: e?.message,
            name: e?.name,
            code: e?.code
          });
          // Fall through to open modal
        }
      }
      
      // If no wallet selected or connecting, just open modal
      if (!wallet || !wallet.adapter || connecting) {
        setVisible(true);
        return;
      }
      
      // If Phantom is detected and no wallet is selected, try selecting it first
      if (typeof window !== "undefined" && (window as any).solana?.isPhantom && !wallet) {
        const phantomWallet = wallets.find((w: any) => w.adapter.name === "Phantom");
        if (phantomWallet) {
          console.log("[ConnectWallet] Phantom detected, selecting Phantom wallet...");
          try {
            select(phantomWallet.adapter.name);
            console.log("[ConnectWallet] Phantom wallet selected, attempting connect...");
            // Wait a tick for selection to register
            await new Promise(resolve => setTimeout(resolve, 50));
            try {
              await connect();
              console.log("[ConnectWallet] ✅ Direct Phantom connect successful!");
              return;
            } catch (e: any) {
              console.error("[ConnectWallet] Direct Phantom connect failed:", e);
              console.error("[ConnectWallet] Error details:", {
                message: e?.message,
                name: e?.name,
                code: e?.code
              });
              // Fall through to open modal
            }
          } catch (err) {
            console.error("[ConnectWallet] Failed to select Phantom:", err);
          }
        }
      }
      
      // Open the wallet selection modal
      try {
        setVisible(true);
        console.log("[ConnectWallet] Wallet modal opened successfully");
      } catch (err) {
        console.error("[ConnectWallet] ❌ Failed to open wallet modal:", err);
      }
      return;
    }
    // connected: ensure session is established
    try {
      const me = await signInIfNeeded();
      // If no username, prompt immediately
      if (!username && (!me?.ok || !me?.user?.username)) {
        setAskUsername(true);
        setHasPrompted(true);
        return;
      }
    } catch (e) {
      console.error("Error in signInIfNeeded:", e);
    }
    // Open menu (allows disconnect even without username)
    setMenuOpen(v => !v);
  };

  // Reset hasPrompted when wallet disconnects
  useEffect(() => {
    if (!connected) {
      setHasPrompted(false);
      setMenuOpen(false);
    }
  }, [connected]);

  const label = !connected
    ? "connect wallet"
    : (username ? `@${username}` : (publicKey ? shorten(publicKey.toBase58()) : (wallet?.adapter?.name || "wallet")));

  const available = wallets
    .filter((w: any) =>
      w.readyState === WalletReadyState.Installed ||
      w.readyState === WalletReadyState.Loadable
    )
    .filter((w: any) => w.adapter.name === "Phantom");

  // Debug: log wallet states (expanded to show full object)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const states = {
        connected,
        connecting,
        publicKey: publicKey?.toBase58(),
        wallet: wallet?.adapter?.name,
        walletsCount: wallets?.length,
        availableCount: available.length,
        wallets: wallets?.map((w: any) => ({
          name: w.adapter?.name,
          readyState: w.readyState,
          installed: w.readyState === WalletReadyState.Installed
        }))
      };
      console.log("[ConnectWallet] Wallet states:", JSON.stringify(states, null, 2));
      
      // Log when connection state changes
      if (connected) {
        console.log("[ConnectWallet] ✅ Wallet connected!", publicKey?.toBase58());
      } else if (connecting) {
        console.log("[ConnectWallet] ⏳ Connecting...");
      }
    }
  }, [connected, connecting, publicKey, wallet, wallets, available]);

  // Listen for wallet connection events
  useEffect(() => {
    if (!wallet?.adapter) return;
    
    const handleConnect = () => {
      console.log("[ConnectWallet] 🔌 Wallet adapter connect event fired");
    };
    
    const handleDisconnect = () => {
      console.log("[ConnectWallet] 🔌 Wallet adapter disconnect event fired");
    };
    
    const handleError = (error: any) => {
      console.error("[ConnectWallet] ❌ Wallet adapter error:", error);
    };

    wallet.adapter.on?.("connect", handleConnect);
    wallet.adapter.on?.("disconnect", handleDisconnect);
    wallet.adapter.on?.("error", handleError);

    return () => {
      wallet.adapter.off?.("connect", handleConnect);
      wallet.adapter.off?.("disconnect", handleDisconnect);
      wallet.adapter.off?.("error", handleError);
    };
  }, [wallet]);

  return (
    <div className="relative" ref={menuRef}>
      <Button
        variant="default"
        onClick={onPrimaryClick}
        className={`font-black flex items-center gap-2 text-sm sm:text-base ${className || ""}`}
        disabled={connecting}
        aria-busy={connecting}
      >
        <img src={lightbulbIcon} alt="" className="w-6 h-6 sm:w-7 sm:h-7" />
        {label}
      </Button>

      {connected && menuOpen && (
        <div
          style={{ position: "absolute", right: 0, top: "110%", zIndex: 60, minWidth: 240,
                   background: "#fff", border: "1px solid #ddd", borderRadius: 8,
                   boxShadow: "0 6px 24px rgba(0,0,0,.15)" }}
        >
          {!username && (
            <button
              onClick={() => { setMenuOpen(false); setAskUsername(true); setHasPrompted(true); }}
              style={{ display: "block", width: "100%", textAlign: "left", padding: "10px 12px", borderBottom: "1px solid #eee" }}
            >
              set username
            </button>
          )}

          {username && (
            <div style={{ padding: "10px 12px", borderBottom: "1px solid #eee", fontSize: 14, fontWeight: 500 }}>
              @{username}
            </div>
          )}

          {available.length > 1 && (
          <div style={{ borderBottom: "1px solid #eee", padding: "6px 12px", fontSize: 12, opacity: .7 }}>
            switch wallet
          </div>
          )}
          {available.map((w:any) => (
            <button
              key={w.adapter.name}
              onClick={async () => {
                setMenuOpen(false);
                try { await disconnect(); } catch (e) { console.error("Error disconnecting:", e); }
                forgetRemembered();
                try { select(w.adapter.name); } catch {}
                try { setVisible(true); } catch {}
              }}
              style={{ display: "block", width: "100%", textAlign: "left", padding: "9px 12px" }}
            >
              {w.adapter.name}
            </button>
          ))}

          <div style={{ borderTop: "1px solid #eee" }} />
          <button
            onClick={async () => {
              setMenuOpen(false);
              try {
                await disconnect();
                console.log("Wallet disconnected");
              } catch (e) {
                console.error("Error disconnecting wallet:", e);
                // Try force disconnect
                try {
                  if (wallet?.adapter?.disconnect) {
                    await wallet.adapter.disconnect();
                  }
                } catch (e2) {
                  console.error("Force disconnect also failed:", e2);
                }
              }
              forgetRemembered();
              await api("/auth/logout", { method: "POST" }).catch(()=>{});
              setHasPrompted(false); // Reset prompt flag
            }}
            style={{ display: "block", width: "100%", textAlign: "left", padding: "10px 12px", color: "#b00020" }}
          >
            disconnect
          </button>
        </div>
      )}

      <UsernameModal
        open={askUsername}
        onOpenChange={(open) => {
          setAskUsername(open);
          // If closing and still no username, user might want to set it later
          if (!open && !username) {
            // Don't auto-open again immediately
          }
        }}
        onSubmitted={(u)=>{
          setUsername(u);
          setHasPrompted(true); // Mark as prompted so we don't prompt again
          // Trigger refresh to ensure it's synced
          window.dispatchEvent(new Event("username-refresh"));
        }}
      />
    </div>
  );
}
