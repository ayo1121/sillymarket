import { Button } from "@/components/ui/button";
import { BettingModal } from "@/components/BettingModal";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LineChart, Line, ResponsiveContainer } from "recharts";
import lightbulbIcon from "@/assets/lightbulb-icon.png";
interface MarketCardProps {
  id: string;
  question: string;
  yesOdds: string;
  noOdds: string;
  volume: string;
  endDate: string;
  yesPercentage: number;
  noPercentage: number;
  imageUrl?: string;
  category: string;
  marketAddress: string;
  creatorAddress: string;
  createdAt: string;
}
export const MarketCard = ({
  id,
  question,
  yesOdds,
  noOdds,
  volume,
  endDate,
  yesPercentage,
  noPercentage,
  imageUrl,
  category,
  marketAddress,
  creatorAddress,
  createdAt
}: MarketCardProps) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedBet, setSelectedBet] = useState<"yes" | "no">("yes");
  const navigate = useNavigate();
  const handleBetClick = (betType: "yes" | "no", e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedBet(betType);
    setModalOpen(true);
  };

  // Mock chart data
  const chartData = [{
    value: 30
  }, {
    value: 35
  }, {
    value: 32
  }, {
    value: 45
  }, {
    value: 50
  }, {
    value: yesPercentage
  }];
  return <div className="win95-window bg-background p-1 mb-4 hover:translate-x-[1px] hover:translate-y-[1px] transition-transform cursor-pointer" onClick={() => navigate(`/market/${id}`)}>
      <div className="bg-primary text-primary-foreground px-3 py-2 flex items-center justify-between mb-1">
        <div className="flex items-center gap-2">
          <img src={lightbulbIcon} alt="" className="w-6 h-6 opacity-90" />
          <span className="font-black tracking-tight text-base">{question}</span>
        </div>
        <div className="flex gap-1">
          <div className="w-3 h-3 win95-raised bg-background"></div>
          <div className="w-3 h-3 win95-raised bg-background"></div>
          <div className="w-3 h-3 win95-raised bg-background"></div>
        </div>
      </div>
      
      <div className="win95-sunken bg-background p-6 relative">
        <div className="space-y-6 relative z-10">
          {/* Market Info Header */}
          <div className="flex items-start gap-4 mb-6">
            {imageUrl && <img src={imageUrl} alt={question} className="w-20 h-20 object-cover flex-shrink-0" />}
            <div className="flex-1 min-w-0">
              <h3 className="text-xl font-black mb-2 leading-tight">{question}</h3>
              <div className="space-y-1 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <span className="font-bold">{category}</span>
                  <span>•</span>
                  <span className="font-mono text-xs truncate">{marketAddress}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground text-xs">
                  <span className="font-mono truncate">{creatorAddress}</span>
                  <span>•</span>
                  <span className="font-bold">{createdAt}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-3">
              <Button variant="yes" className="w-full h-14 text-lg font-black group hover:shadow-lg relative overflow-hidden" onClick={e => handleBetClick("yes", e)}>
                <span className="absolute inset-0 bg-brand-yes opacity-0 group-hover:opacity-20 transition-opacity"></span>
                yes :)
              </Button>
              <div className="win95-sunken bg-input p-3">
                <div className="text-center mb-2">
                  <div className="text-3xl font-black">{yesOdds}</div>
                  <div className="text-xs text-muted-foreground font-bold tracking-wider">payout</div>
                </div>
                <div className="h-12 win95-sunken p-1 bg-background/50">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                      <Line type="monotone" dataKey="value" stroke="hsl(var(--brand-yes))" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-center mt-1">
                  <span className="text-brand-yes font-black text-lg">{yesPercentage}%</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <Button variant="no" className="w-full h-14 text-lg font-black group hover:shadow-lg relative overflow-hidden" onClick={e => handleBetClick("no", e)}>
                <span className="absolute inset-0 bg-brand-no opacity-0 group-hover:opacity-20 transition-opacity"></span>
                no :(
              </Button>
              <div className="win95-sunken bg-input p-3">
                <div className="text-center mb-2">
                  <div className="text-3xl font-black">{noOdds}</div>
                  <div className="text-xs text-muted-foreground font-bold tracking-wider">payout</div>
                </div>
                <div className="h-12 win95-sunken p-1 bg-background/50">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData.map(d => ({
                    value: 100 - d.value
                  }))}>
                      <Line type="monotone" dataKey="value" stroke="hsl(var(--brand-no))" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="text-center mt-1">
                  <span className="text-brand-no font-black text-lg">{noPercentage}%</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="win95-sunken bg-input p-4">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground font-bold tracking-wider">volume</div>
                <div className="font-black text-lg">{volume} sol</div>
              </div>
              <div className="space-y-1">
                <div className="text-xs text-muted-foreground font-bold tracking-wider">closes</div>
                <div className="font-black text-lg">{endDate}</div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none flex items-center justify-center text-[10rem] font-black leading-none">
          :)
        </div>
      </div>

      <BettingModal open={modalOpen} onOpenChange={setModalOpen} question={question} betType={selectedBet} odds={selectedBet === "yes" ? yesOdds : noOdds} />
    </div>;
};