import { deriveView } from '@/lib/marketAdapter';
import { useOnchainBetAdapter } from "@/lib/useOnchainBetAdapter";
import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { BettingModal } from "@/components/BettingModal";
import { CommentsSection } from "@/components/CommentsSection";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip } from "recharts";
import lightbulbIcon from "@/assets/lightbulb-icon.png";
import { ArrowLeft } from "lucide-react";

const MarketDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedBet, setSelectedBet] = useState<"yes" | "no">("yes");
  const { onConfirm } = useOnchainBetAdapter(id);

  // Mock data - would come from blockchain
  const market = {
    id: id || "1",
    question: id === "1" ? "will btc hit $100k in 2025?" : 
              id === "2" ? "will sol flip eth?" : 
              "will ai replace programmers?",
    yesOdds: "2.4x",
    noOdds: "1.7x",
    volume: "1,250",
    endDate: "dec 31, 2025",
    yesPercentage: 58,
    noPercentage: 42,
    description: "bitcoin has been on a steady rise. will it finally break the psychological barrier of $100k by the end of 2025?",
    imageUrl: id === "1" ? "https://images.unsplash.com/photo-1518546305927-5a555bb7020d?w=800&h=400&fit=crop" :
              id === "2" ? "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&h=400&fit=crop" :
              "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=400&fit=crop",
    category: id === "1" ? "crypto" : id === "2" ? "crypto" : "tech",
    marketAddress: id === "1" ? "E9Ud...pump" : id === "2" ? "7xK2...moon" : "Ai3D...tech",
    creatorAddress: id === "1" ? "letterbomb1234" : id === "2" ? "solanamaxi" : "cryptodev42",
    createdAt: id === "1" ? "2d ago" : id === "2" ? "5d ago" : "1w ago",
  };

  const chartData = [
    { time: "nov 1", yes: 45, no: 55 },
    { time: "nov 2", yes: 48, no: 52 },
    { time: "nov 3", yes: 52, no: 48 },
    { time: "nov 4", yes: 50, no: 50 },
    { time: "nov 5", yes: 55, no: 45 },
    { time: "nov 6", yes: 57, no: 43 },
    { time: "nov 7", yes: 58, no: 42 },
  ];

  const recentActivity = [
    { user: "0x7a3...f2d", action: "bet yes", amount: "5 sol", time: "2 mins ago" },
    { user: "0x9b1...c4e", action: "bet no", amount: "3 sol", time: "8 mins ago" },
    { user: "0x2c8...a1f", action: "bet yes", amount: "10 sol", time: "15 mins ago" },
    { user: "0x5d4...b9c", action: "bet yes", amount: "2 sol", time: "23 mins ago" },
    { user: "0x1f6...e7a", action: "bet no", amount: "7 sol", time: "31 mins ago" },
  ];

  const handleBetClick = (betType: "yes" | "no") => {
    setSelectedBet(betType);
    setModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-win95-teal">
      <Header />
      
      <main className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <div className="max-w-6xl mx-auto">
          <Button 
            variant="default" 
            onClick={() => navigate("/")}
            className="mb-4 sm:mb-6 font-black text-sm sm:text-base"
          >
            <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
            back to markets
          </Button>

          {/* Market Header */}
          <div className="win95-window bg-background p-1 mb-4 sm:mb-6">
            <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <img src={lightbulbIcon} alt="" className="w-4 h-4 sm:w-5 sm:h-5 opacity-80" />
                <span className="font-black tracking-tight text-xs sm:text-sm">market details</span>
              </div>
              <div className="flex gap-1">
                <div className="w-2 h-2 sm:w-3 sm:h-3 win95-raised bg-background"></div>
                <div className="w-2 h-2 sm:w-3 sm:h-3 win95-raised bg-background"></div>
                <div className="w-2 h-2 sm:w-3 sm:h-3 win95-raised bg-background"></div>
              </div>
            </div>
            
            <div className="win95-sunken bg-background p-3 sm:p-6">
              <div className="flex flex-col sm:flex-row items-start gap-4 sm:gap-6 mb-4 sm:mb-6">
                {market.imageUrl && (
                  <div className="win95-sunken p-2 bg-input flex-shrink-0 w-full sm:w-auto" style={{ borderColor: 'hsl(var(--primary))' }}>
                    <img 
                      src={market.imageUrl} 
                      alt={market.question}
                      className="w-full h-48 sm:w-32 sm:h-32 object-cover"
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <h1 className="text-2xl sm:text-4xl font-black mb-3 sm:mb-4 break-words">{market.question}</h1>
                  <div className="space-y-2 mb-3 sm:mb-4">
                    <div className="flex flex-wrap items-center gap-2 text-muted-foreground text-sm sm:text-base">
                      <span className="font-bold">{market.category}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="font-mono text-xs sm:text-sm truncate">{market.marketAddress}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 text-muted-foreground text-xs sm:text-sm">
                      <span className="font-mono truncate">{market.creatorAddress}</span>
                      <span className="hidden sm:inline">•</span>
                      <span className="font-bold">{market.createdAt}</span>
                    </div>
                  </div>
                  <p className="text-muted-foreground font-bold text-sm sm:text-base">{market.description}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
                <div className="win95-sunken bg-input p-3 sm:p-4">
                  <div className="text-xs text-muted-foreground font-bold tracking-wider mb-1">total volume</div>
                  <div className="text-xl sm:text-2xl font-black">{market.volume} sol</div>
                </div>
                <div className="win95-sunken bg-input p-3 sm:p-4">
                  <div className="text-xs text-muted-foreground font-bold tracking-wider mb-1">closes</div>
                  <div className="text-xl sm:text-2xl font-black">{market.endDate}</div>
                </div>
                <div className="win95-sunken bg-input p-3 sm:p-4">
                  <div className="text-xs text-muted-foreground font-bold tracking-wider mb-1">status</div>
                  <div className="text-xl sm:text-2xl font-black text-brand-yes">active</div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
            {/* Betting Panel */}
            <div className="lg:col-span-1">
              <div className="win95-window bg-background p-1">
                <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 mb-1">
                  <span className="font-black text-xs sm:text-sm tracking-tight">place your bet</span>
                </div>
                
                <div className="win95-sunken bg-background p-3 sm:p-4 space-y-3 sm:space-y-4">
                  <Button 
                    variant="yes" 
                    className="w-full h-16 text-xl font-black group hover:shadow-lg relative overflow-hidden"
                    onClick={() => handleBetClick("yes")}
                  >
                    <span className="absolute inset-0 bg-brand-yes opacity-0 group-hover:opacity-20 transition-opacity"></span>
                    yes :)
                  </Button>
                  <div className="win95-sunken bg-input p-3 text-center">
                    <div className="text-4xl font-black">{market.yesOdds}</div>
                    <div className="text-xs text-muted-foreground font-bold tracking-wider">payout</div>
                    <div className="mt-2 text-brand-yes text-2xl font-black">{market.yesPercentage}%</div>
                  </div>

                  <div className="h-px bg-border my-4"></div>

                  <Button 
                    variant="no" 
                    className="w-full h-16 text-xl font-black group hover:shadow-lg relative overflow-hidden"
                    onClick={() => handleBetClick("no")}
                  >
                    <span className="absolute inset-0 bg-brand-no opacity-0 group-hover:opacity-20 transition-opacity"></span>
                    no :(
                  </Button>
                  <div className="win95-sunken bg-input p-3 text-center">
                    <div className="text-4xl font-black">{market.noOdds}</div>
                    <div className="text-xs text-muted-foreground font-bold tracking-wider">payout</div>
                    <div className="mt-2 text-brand-no text-2xl font-black">{market.noPercentage}%</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Charts and Activity */}
            <div className="lg:col-span-2 space-y-4 sm:space-y-6">
              {/* Chart */}
              <div className="win95-window bg-background p-1">
                <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 mb-1">
                  <span className="font-black text-xs sm:text-sm tracking-tight">probability over time</span>
                </div>
                
                <div className="win95-sunken bg-background p-3 sm:p-6">
                  <div className="h-48 sm:h-64 win95-sunken p-2 sm:p-4 bg-input">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis 
                          dataKey="time" 
                          stroke="hsl(var(--foreground))"
                          style={{ fontSize: '12px', fontWeight: 'bold' }}
                        />
                        <YAxis 
                          stroke="hsl(var(--foreground))"
                          style={{ fontSize: '12px', fontWeight: 'bold' }}
                        />
                        <Tooltip 
                          contentStyle={{ 
                            background: 'hsl(var(--background))',
                            border: '2px solid hsl(var(--foreground))',
                            borderRadius: '0',
                            fontWeight: 'bold'
                          }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="yes" 
                          stroke="hsl(var(--brand-yes))" 
                          strokeWidth={3}
                          name="yes %"
                        />
                        <Line 
                          type="monotone" 
                          dataKey="no" 
                          stroke="hsl(var(--brand-no))" 
                          strokeWidth={3}
                          name="no %"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Recent Activity */}
              <div className="win95-window bg-background p-1">
                <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 mb-1">
                  <span className="font-black text-xs sm:text-sm tracking-tight">recent activity</span>
                </div>
                
                <div className="win95-sunken bg-background p-3 sm:p-4">
                  <div className="space-y-2">
                    {recentActivity.map((activity, index) => (
                      <div 
                        key={index}
                        className="win95-raised p-3 bg-background hover:bg-accent transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="win95-sunken px-2 py-1 bg-input font-black text-xs">
                              {activity.user}
                            </span>
                            <span className={`font-black text-sm ${
                              activity.action.includes("yes") ? "text-brand-yes" : "text-brand-no"
                            }`}>
                              {activity.action}
                            </span>
                          </div>
                          <div className="text-right">
                            <div className="font-black text-sm">{activity.amount}</div>
                            <div className="text-xs text-muted-foreground font-bold">{activity.time}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Comments Section */}
              <CommentsSection marketId={market.id} />
            </div>
          </div>
        </div>
      </main>

      <BettingModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        question={market.question}
        betType={selectedBet}
        odds={selectedBet === "yes" ? market.yesOdds : market.noOdds}
        onConfirm={onConfirm}
      />
    </div>
  );
};

export default MarketDetails;
