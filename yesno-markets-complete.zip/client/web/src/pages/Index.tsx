import { Header } from "@/components/Header";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useAnchorProgram } from "@/solana/program";
import { fetchAllMarkets } from "@/solana/read";
import { useState, useEffect } from "react";
import { MarketCard } from "@/components/MarketCard";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { useNotifications } from "@/hooks/useNotifications";
import { PublicKey } from "@solana/web3.js";

const Index = () => {
  const navigate = useNavigate();
  const program = useAnchorProgram();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [sortBy, setSortBy] = useState<string>("newest");
  const [markets, setMarkets] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch real markets from blockchain
  useEffect(() => {
    (async () => {
      if (!program) {
        setMarkets([]);
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const all = await fetchAllMarkets(program);
        // Transform blockchain data to MarketCard format
        const transformed = all.map((r: any) => {
          const account = r.account;
          const cutoffTs = account.cutoffTs || account.cutoff_ts || 0;
          const createdTs = account.createdTs || account.created_ts || 0;
          const cutoffDate = new Date(cutoffTs * 1000);
          const createdDate = new Date(createdTs * 1000);
          const now = Math.floor(Date.now() / 1000);
          const isActive = account.state === 1;
          const pools = account.pools || [];
          const totalPool = account.totalPool || account.total_pool || 0;
          const outcomesCount = account.outcomesCount || account.outcomes_count || 2;
          
          // Calculate odds (simplified - in reality you'd need to calculate based on pool sizes)
          const pool0 = pools[0] || 0;
          const pool1 = pools[1] || 0;
          const total = pool0 + pool1;
          const yesOdds = total > 0 && pool0 > 0 ? (total / pool0).toFixed(1) + "x" : "N/A";
          const noOdds = total > 0 && pool1 > 0 ? (total / pool1).toFixed(1) + "x" : "N/A";
          const yesPercentage = total > 0 ? Math.round((pool0 / total) * 100) : 50;
          const noPercentage = total > 0 ? Math.round((pool1 / total) * 100) : 50;
          
          return {
            id: r.publicKey.toBase58(),
            question: `Market ${r.publicKey.toBase58().slice(0, 8)}...`, // We don't store question text on-chain, only hash
            yesOdds,
            noOdds,
            volume: (totalPool / 1_000_000_000).toFixed(0),
            endDate: cutoffDate.toLocaleDateString(),
            yesPercentage,
            noPercentage,
            imageUrl: account.imageUrl || account.image_url || "",
            category: "onchain",
            marketAddress: r.publicKey.toBase58().slice(0, 8) + "..." + r.publicKey.toBase58().slice(-4),
            creatorAddress: (account.creator || "").toString().slice(0, 8) + "...",
            createdAt: getTimeAgo(createdDate),
            publicKey: r.publicKey,
            account: account,
            cutoffTs,
            isActive: isActive && now < cutoffTs,
          };
        });
        setMarkets(transformed);
      } catch (e: any) {
        console.error("Error fetching markets:", e);
        setError(e?.message || String(e));
        setMarkets([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [program]);

  function getTimeAgo(date: Date): string {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return `${Math.floor(diffDays / 7)}w ago`;
  }

  // Filter and sort markets
  const filteredAndSortedMarkets = markets.filter(market => {
    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      if (!market.question.toLowerCase().includes(query) &&
          !market.creatorAddress.toLowerCase().includes(query) &&
          !market.marketAddress.toLowerCase().includes(query)) {
        return false;
      }
    }

    // Filter by status
    if (statusFilter !== "all") {
      if (statusFilter === "active" && !market.isActive) return false;
      if (statusFilter === "closed" && market.isActive) return false;
    }

    return true;
  }).sort((a, b) => {
      switch (sortBy) {
        case "volume":
        return parseFloat(b.volume) - parseFloat(a.volume);
        case "ending-soon":
        return a.cutoffTs - b.cutoffTs;
        case "newest":
        default:
        return b.cutoffTs - a.cutoffTs;
      }
    });

  useNotifications(markets);

  return (
    <div className="min-h-screen bg-win95-teal">
      <div className="max-w-5xl mx-auto px-2 sm:px-4 py-4 sm:py-8 pb-8 sm:pb-16">
        <Header />
        
        <div className="win95-window bg-background p-1 mb-4 sm:mb-8">
          <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 mb-1 flex items-center gap-2">
            <span className="text-lg sm:text-xl font-black">:)</span>
            <span className="font-black text-xs tracking-tight sm:text-base">create your own market</span>
          </div>
          <div className="win95-sunken bg-background p-4 sm:p-8 text-center space-y-3 sm:space-y-4">
            <p className="text-base sm:text-lg font-bold">got some silliness to share? create a market and let the world bet on it.</p>
            <Button variant="default" size="lg" className="font-black text-sm sm:text-base px-6 sm:px-8 w-full sm:w-auto" onClick={() => navigate("/create-market")}>
              + new market
            </Button>
          </div>
        </div>

        <div className="mb-4 sm:mb-6">
          <h2 className="text-xl sm:text-2xl font-black mb-3 sm:mb-4 flex flex-col sm:flex-row items-start sm:items-center gap-2 sm:gap-3">
            <span className="win95-sunken px-3 sm:px-4 py-2 sm:py-3 bg-input text-base sm:text-xl">active markets</span>
            <span className="text-sm sm:text-base text-muted-foreground font-bold">
              {loading ? "(loading...)" : error ? `(error: ${error})` : `(${filteredAndSortedMarkets.length} shown)`}
            </span>
          </h2>
          
          {/* Search and Filters */}
          <div className="win95-window bg-background p-1 mb-3 sm:mb-4">
            <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 mb-1">
              <span className="font-black text-xs tracking-tight sm:text-base">search & filters</span>
            </div>
            <div className="win95-sunken bg-background p-3 sm:p-4 space-y-3 sm:space-y-4">
              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="search markets..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="win95-sunken bg-background font-bold pl-8 sm:pl-10 text-sm sm:text-base"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-black mb-2 block">status</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="win95-sunken bg-background font-bold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background border-2 border-foreground z-50">
                      <SelectItem value="all" className="font-bold">all markets</SelectItem>
                      <SelectItem value="active" className="font-bold">active</SelectItem>
                      <SelectItem value="closed" className="font-bold">closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-xs font-black mb-2 block">sort by</label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="win95-sunken bg-background font-bold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background border-2 border-foreground z-50">
                      <SelectItem value="newest" className="font-bold">newest first</SelectItem>
                      <SelectItem value="ending-soon" className="font-bold">ending soon</SelectItem>
                      <SelectItem value="volume" className="font-bold">highest volume</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </div>

        {!program && (
          <div className="win95-window bg-background p-1">
            <div className="win95-sunken bg-background p-4 sm:p-8 text-center">
              <p className="text-base sm:text-lg font-bold text-muted-foreground mb-2">
                Connect wallet to load on-chain markets
              </p>
              <p className="text-sm text-muted-foreground">
                Make sure your wallet is set to <strong>Solana Devnet</strong>
              </p>
            </div>
          </div>
        )}

        {loading && (
          <div className="win95-window bg-background p-1">
            <div className="win95-sunken bg-background p-4 sm:p-8 text-center">
              <p className="text-base sm:text-lg font-bold">Loading markets from blockchain...</p>
            </div>
          </div>
        )}

        {error && (
          <div className="win95-window bg-background p-1">
            <div className="win95-sunken bg-background p-4 sm:p-8 text-center">
              <p className="text-base sm:text-lg font-bold text-red-600">Error loading markets: {error}</p>
              <p className="text-sm text-muted-foreground mt-2">
                Make sure your wallet is connected to <strong>Solana Devnet</strong> and try again
              </p>
            </div>
          </div>
        )}

        <div className="space-y-0">
          {filteredAndSortedMarkets.length > 0 ? (
            filteredAndSortedMarkets.map((market) => (
              <div key={market.id} onClick={() => navigate(`/market/${market.publicKey.toBase58()}`)} className="cursor-pointer">
                <MarketCard {...market} />
              </div>
            ))
          ) : !loading && !error && program ? (
            <div className="win95-window bg-background p-1">
              <div className="win95-sunken bg-background p-4 sm:p-8 text-center">
                <p className="text-base sm:text-lg font-bold text-muted-foreground">
                  {searchQuery || statusFilter !== "all" 
                    ? "no markets found matching your filters"
                    : "no markets found. create one to get started!"}
                </p>
              </div>
            </div>
          ) : null}
        </div>

        <div className="win95-window bg-background p-1 mt-6 sm:mt-8">
          <div className="bg-primary text-primary-foreground px-2 sm:px-3 py-2 mb-1">
            <span className="font-black text-xs tracking-tight sm:text-base">about</span>
          </div>
          <div className="win95-sunken bg-background p-4 sm:p-6">
            <div className="space-y-3 sm:space-y-4">
              <p className="text-base leading-relaxed font-bold sm:text-xl">
                <span className="text-2xl sm:text-3xl mr-2 sm:mr-3 font-black"></span>
                place your bets on any silly outcome. winners take all.
              </p>
              <div className="flex flex-wrap gap-3 sm:gap-6 text-xs sm:text-sm">
                <div className="flex items-center gap-2 sm:gap-3">
                  <span className="win95-sunken px-2 sm:px-3 py-1 sm:py-2 bg-input font-black text-xs">✓</span>
                  <span className="font-bold">100% on-chain</span>
                </div>
                <div className="flex items-center gap-2 sm:gap-3">
                  <span className="win95-sunken px-2 sm:px-3 py-1 sm:py-2 bg-input font-black text-xs">✓</span>
                  <span className="font-bold">no house edge</span>
                </div>
                <div className="flex items-center gap-2 sm:gap-3">
                  <span className="win95-sunken px-2 sm:px-3 py-1 sm:py-2 bg-input font-black text-xs">✓</span>
                  <span className="font-bold">instant payouts on resolution</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-8 sm:mt-12 text-center">
          <div className="win95-sunken bg-background p-3 sm:p-4 inline-block">
            <p className="text-sm font-black tracking-tight">:) sillymarket </p>
            <p className="text-xs text-muted-foreground mt-1 sm:mt-2 font-bold">silly bets, silly outcomes</p>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default Index;
