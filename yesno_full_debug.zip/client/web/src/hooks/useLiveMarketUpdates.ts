import { useEffect, useRef, useState, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabaseClient } from "@/integrations/supabase/client";
import { queryKeys } from "@/lib/queryKeys";

/**
 * Real-Time Market Updates Hook
 * 
 * Subscribes to Supabase realtime for bet updates and refreshes market data.
 * Falls back to periodic polling if real-time connection fails.
 * 
 * Features:
 * - Supabase realtime subscription to 'bets' table
 * - Automatic cache invalidation on new bets
 * - Graceful fallback to 60s polling
 * - Visibility-aware polling (pauses when page hidden)
 * - Connection status tracking
 * 
 * TODO: WebSocket integration for direct market updates
 * When backend WebSocket is available, replace Supabase subscription with:
 * 
 * WebSocket URL: wss://api.example.com/markets/live
 * 
 * Message format:
 * {
 *   type: 'bet_placed' | 'market_resolved' | 'probability_changed',
 *   marketId: string,
 *   data: {...}
 * }
 * 
 * Events to handle:
 * - bet_placed: Update specific market probabilities
 * - market_resolved: Invalidate and refetch market
 * - probability_changed: Update probabilities in real-time
 * 
 * Example WebSocket implementation:
 * ```typescript
 * const ws = new WebSocket('wss://api.example.com/markets/live');
 * 
 * ws.onmessage = (event) => {
 *   const data = JSON.parse(event.data);
 *   
 *   switch (data.type) {
 *     case 'bet_placed':
 *       queryClient.setQueryData(
 *         queryKeys.markets.detail(data.marketId),
 *         (old) => ({ ...old, ...data.updates })
 *       );
 *       break;
 *       
 *     case 'market_resolved':
 *       queryClient.invalidateQueries({
 *         queryKey: queryKeys.markets.detail(data.marketId)
 *       });
 *       break;
 *       
 *     case 'probability_changed':
 *       queryClient.setQueryData(
 *         queryKeys.markets.detail(data.marketId),
 *         (old) => ({ ...old, outcomes: data.outcomes })
 *       );
 *       break;
 *   }
 * };
 * 
 * ws.onerror = () => {
 *   setIsConnected(false);
 *   startFallbackPolling();
 * };
 * ```
 */
export const useLiveMarketUpdates = (enabled: boolean = true) => {
    const queryClient = useQueryClient();
    const [isConnected, setIsConnected] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const fallbackIntervalRef = useRef<NodeJS.Timeout | null>(null);

    // Start fallback polling if real-time fails
    const startFallbackPolling = useCallback(() => {
        if (fallbackIntervalRef.current) return; // Already polling

        // Only log in development
        if (import.meta.env.DEV) {
            console.log('[LiveUpdates] Fallback polling enabled');
        }

        const poll = () => {
            // Only poll if page is visible
            if (document.visibilityState === 'visible') {
                queryClient.invalidateQueries({ queryKey: queryKeys.markets.all });
            }
        };

        // Poll every 120 seconds (reduced from 60s to minimize RPC load)
        fallbackIntervalRef.current = setInterval(poll, 120 * 1000);
    }, [queryClient]);

    // Stop fallback polling
    const stopFallbackPolling = useCallback(() => {
        if (fallbackIntervalRef.current) {
            clearInterval(fallbackIntervalRef.current);
            fallbackIntervalRef.current = null;
        }
    }, []);

    useEffect(() => {
        if (!enabled) return;

        if (import.meta.env.DEV) {
            console.log('[LiveUpdates] Initializing Supabase realtime');
        }

        // Supabase realtime subscription for bet updates
        const channel = supabaseClient
            .channel('bets-changes')
            .on(
                'postgres_changes',
                {
                    event: 'INSERT',
                    schema: 'public',
                    table: 'bets',
                },
                async (payload) => {
                    if (import.meta.env.DEV) {
                        console.log('[LiveUpdates] New bet:', payload.new);
                    }

                    // Invalidate markets query to trigger refetch
                    queryClient.invalidateQueries({ queryKey: queryKeys.markets.all });

                    // Optionally: Update specific market in cache
                    const marketPubkey = (payload.new as any).market_pubkey;
                    if (marketPubkey) {
                        queryClient.invalidateQueries({
                            queryKey: queryKeys.markets.detail(marketPubkey)
                        });
                    }
                }
            )
            .subscribe((status) => {
                if (import.meta.env.DEV) {
                    console.log('[LiveUpdates] Status:', status);
                }

                if (status === 'SUBSCRIBED') {
                    setIsConnected(true);
                    setError(null);
                    // Clear fallback polling when connected
                    stopFallbackPolling();
                } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
                    setIsConnected(false);
                    setError('Real-time connection failed');
                    // Start fallback polling
                    startFallbackPolling();
                }
            });

        // Cleanup
        return () => {
            if (import.meta.env.DEV) {
                console.log('[LiveUpdates] Cleanup');
            }
            channel.unsubscribe();
            stopFallbackPolling();
        };
    }, [enabled, queryClient, startFallbackPolling, stopFallbackPolling]);

    // Handle page visibility changes
    useEffect(() => {
        if (!enabled) return;

        const handleVisibilityChange = () => {
            if (document.visibilityState === 'hidden' && fallbackIntervalRef.current) {
                stopFallbackPolling();
            } else if (document.visibilityState === 'visible' && !isConnected) {
                startFallbackPolling();
            }
        };

        document.addEventListener('visibilitychange', handleVisibilityChange);
        return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
    }, [isConnected, enabled, startFallbackPolling, stopFallbackPolling]);

    return { isConnected, error };
};
